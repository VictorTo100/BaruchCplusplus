
#include"Options.h"
#include"EuropeanEquityOptions.h"
#include<iostream>
#include<string>
using namespace std;
using namespace VISHRUTTALEKAR;

int main()
{
	using OPTIONS::EuropeanEquityOptions;

	EuropeanEquityOptions callOption("Call", 60, 0.08, 65, 0.30, 0.25);

	double callPrice = callOption.Price();

	std::cout << "Call Price is: " << callPrice << endl;

	double putPrice = callOption.PutWithParity(callPrice);

	std::cout << "Put Price is: " << putPrice << endl;

	map<string, double> resultCheck = callOption.CheckParity(callPrice, putPrice); 
	
	std::map<std::string, double>::iterator it;

	for (it = resultCheck.begin(); it != resultCheck.end(); it++)
	{
		cout << "The Result of the Parity Check is: " << it->first << ":" << it->second << endl;
	}
	
	return 0;
}